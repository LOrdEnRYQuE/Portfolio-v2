import profile from './portfolio_profile.json';

export function ResumeDownloadSection() {
  return (
    <section className="rounded-3xl border border-white/10 bg-black text-white p-8 md:p-10">
      <div className="grid gap-8 md:grid-cols-[220px_1fr]">
        <div>
          <img
            src="/images/profile-attilla.jpg"
            alt={profile.name}
            className="w-full rounded-2xl object-cover shadow-2xl"
          />
        </div>
        <div className="space-y-5">
          <div>
            <p className="text-sm uppercase tracking-[0.22em] text-amber-300">Downloadable Résumé</p>
            <h2 className="mt-2 text-3xl font-semibold">{profile.name}</h2>
            <p className="mt-2 text-amber-200">{profile.role}</p>
            <p className="mt-4 max-w-3xl text-white/75">{profile.summary}</p>
          </div>

          <div className="flex flex-wrap gap-3">
            <a
              href="/Attila_Lazar_Resume_Portfolio.pdf"
              download
              className="rounded-xl bg-amber-400 px-5 py-3 font-medium text-black transition hover:opacity-90"
            >
              Download PDF Resume
            </a>
            <a
              href={`https://${profile.github}`}
              target="_blank"
              rel="noreferrer"
              className="rounded-xl border border-white/15 px-5 py-3 font-medium text-white transition hover:bg-white/5"
            >
              View GitHub
            </a>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            {profile.strengths.map((item) => (
              <div key={item} className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white/80">
                {item}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
